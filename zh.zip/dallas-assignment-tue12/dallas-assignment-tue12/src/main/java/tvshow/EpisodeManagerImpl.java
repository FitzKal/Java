package tvshow;

import java.time.DayOfWeek;
import java.util.*;
import java.util.stream.Collectors;

public class EpisodeManagerImpl implements EpisodeManager{
    @Override
    public List<Integer> getSeasonsWithLongEpisodes() {
        return List.of();
    }

    @Override
    public Optional<String> getShortestSummaryOfFirstEpisodes() {
        return getEpisodes().stream()
                .filter(episode -> episode.number() ==1)
                .map(Episode::summary)
                .min(Comparator.comparing(String::length));
    }

    @Override
    public Map<DayOfWeek, Long> getNumberOfRegularEpisodesByDayOfAirDate() {
        return getEpisodes().stream()
                .filter(episode -> episode.type().equals(Type.REGULAR))
                .collect(Collectors.groupingBy(episode -> episode.airDate().getDayOfWeek(),Collectors.counting()));
    }

    @Override
    public long getNumberOfDifferentWriters() {
       return 0;
      // return getEpisodes().stream()
        //.flatMap(c -> c.guestCrew().stream()
        //.filter(crewMember -> crewMember.role() != null)
        //         .filter(crewMember -> crewMember.role().equals("Writer"))).count();
    }

    @Override
    public int getTotalRuntimeOfEpisodesWhoseTitleContainsEwing() {
        return getEpisodes().stream()
                .filter(episode -> episode.title().contains("Ewing"))
                .mapToInt(Episode::runtime)
                .sum();
    }

    public static void main(String[] args) {
        var episode = new EpisodeManagerImpl();
        System.out.println(episode.getShortestSummaryOfFirstEpisodes());
        System.out.println(episode.getNumberOfRegularEpisodesByDayOfAirDate());
        //System.out.println(episode.getNumberOfDifferentWriters());
        System.out.println(episode.getTotalRuntimeOfEpisodesWhoseTitleContainsEwing());
    }
}
