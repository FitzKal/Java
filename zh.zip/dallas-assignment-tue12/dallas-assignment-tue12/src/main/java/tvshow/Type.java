package tvshow;

public enum Type {
    REGULAR,
    INSIGNIFICANT_SPECIAL,
    SIGNIFICANT_SPECIAL
}