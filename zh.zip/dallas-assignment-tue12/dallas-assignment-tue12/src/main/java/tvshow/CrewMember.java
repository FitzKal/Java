package tvshow;

import java.io.Serializable;

public record CrewMember(String name, String role) implements Serializable {
}
