package Model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.TreeSet;

public class Company implements Serializable {
    String name;
    String nameOfLeader;
    TreeSet<Department> departments = new TreeSet<>();

    public Company(String name, String nameOfLeader) {
        this.name = name;
        this.nameOfLeader = nameOfLeader;
    }

    public String getName() {
        return name;
    }

    public String getNameOfLeader() {
        return nameOfLeader;
    }

    public void setNameOfLeader(String nameOfLeader) {
        this.nameOfLeader = nameOfLeader;
    }
    public void addDepartment(Department department){
        this.departments.add(department);
    }

    public void removeDepartment (Department department){
        this.departments.remove(department);
    }

    public TreeSet<Department> getDepartments() {
        return departments;
    }

    @Override
    public String toString(){
        StringBuilder str = new StringBuilder();
        str.append("Company name: ");
        str.append(this.name);
        str.append(" CEO name: ");
        str.append(this.nameOfLeader);
        return str.toString();
    }
}
