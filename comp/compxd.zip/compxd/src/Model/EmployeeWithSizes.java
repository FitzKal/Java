package Model;

import Exceptions.HeightException;
import Exceptions.ShoeSizeException;
import Exceptions.SizeException;
import Exceptions.WrongBirthDateException;

import java.time.LocalDate;

public class EmployeeWithSizes extends Employee{
    int shoeSize;
    int heightInCm;

    public EmployeeWithSizes(String name, LocalDate birthDate, int id, Department department, int heightInCm, int shoeSize) throws WrongBirthDateException, SizeException {
        super(name, birthDate, id, department);
        if (heightInCm > 140){
            this.heightInCm = heightInCm;
        }else {
            throw new HeightException("Torpe geci");
        }
        if (shoeSize > 50 || shoeSize < 35){
            throw new ShoeSizeException("Restarted");
        }else {
            this.shoeSize = shoeSize;
        }
    }

    public int getShoeSize() {
        return shoeSize;
    }

    public void setShoeSize(int shoeSize) {
        this.shoeSize = shoeSize;
    }

    public int getHeightInCm() {
        return heightInCm;
    }

    public void setHeightInCm(int heightInCm) {
        this.heightInCm = heightInCm;
    }
    @Override
    public String toString(){
        StringBuilder str = new StringBuilder();
        str.append(" Height: ");
        str.append(this.heightInCm);
        str.append(" Shoe size: ");
        str.append(this.shoeSize);
        return str.toString();
    }
}
