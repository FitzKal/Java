package Model;

import Exceptions.DeptNotContainEmpException;
import Exceptions.WrongBirthDateException;

import java.time.LocalDate;
import java.util.Objects;

public class Employee extends Person implements Comparable<Employee>{
    int id;
    Department department;



    public Employee(String name, LocalDate birthDate, int id, Department department) throws WrongBirthDateException {
        super(name, birthDate);
        this.id = id;
        this.department = department;
    }


    public int getId() {
        return id;
    }

    /*public  void  setDepartmentNull(Department department){
            this.department = null;

    }*/

    public void setDepartment(Department department) throws DeptNotContainEmpException {

        if (department == null){
            this.department = null;
        }
        else if(department.getEmployees().contains(this)){
                this.department = department;
        }else {
            throw new DeptNotContainEmpException("Department contains no such employee");
        }
        this.department = department;
    }


    @Override
    public int compareTo(Employee o) {
        return (this.id-o.id);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Employee employee)) return false;
        return id == employee.id && Objects.equals(department, employee.department);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, department);
    }
    @Override
    public String toString(){
        StringBuilder str = new StringBuilder();
        str.append("id = ");
        str.append(this.id);
        str.append(" Department = ");
        str.append(department);
        str.append(" toString = ");
        str.append(super.toString());
        return str.toString();

    }
}
