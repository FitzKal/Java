package Model;

import Exceptions.WrongBirthDateException;

import java.time.LocalDate;

public class Person {
    String name;
    LocalDate birthDate;
    String nickName;

    public Person(String name,LocalDate birthDate ) throws WrongBirthDateException {
        if(birthDate.isBefore(LocalDate.of(1965,1,1) )||  birthDate.isAfter(LocalDate.of(2018,1,1))){
            throw new  WrongBirthDateException("The given birthdate is not valid");
        }
        this.name = name;
        this.birthDate = birthDate;
    }

    public Person(String name, LocalDate birthDate, String nickName) throws WrongBirthDateException {
        if(birthDate.isBefore(LocalDate.of(1965,1,1) )||  birthDate.isAfter(LocalDate.of(2018,1,1))){
            throw new  WrongBirthDateException("The given birthdate is not valid");
        }
        this.name = name;
        this.birthDate = birthDate;
        this.nickName = nickName;
    }

    public String getName() {
        return name;
    }

    public LocalDate getBirthDate() {
        return birthDate;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    @Override
    public String toString() {
            StringBuilder str = new StringBuilder();
            str.append("Name: ");
            str.append(this.name);
            str.append(", The BirthDate: ");
            str.append(this.birthDate);
            str.append(", Nickname = ");
            if(this.nickName == null){
                str.append("Null");
            }else {
                str.append(this.nickName);
            }
            return str.toString();
    }
}
