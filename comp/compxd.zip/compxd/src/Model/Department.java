package Model;

import Exceptions.DeptNotContainEmpException;

import java.util.HashSet;

public class Department implements Comparable<Department> {
    String id;
    String name;
    HashSet<Employee> employees;

    public Department(String id, String name) {
        this.id = id;
        this.name = name;
        employees = new HashSet<>();
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public HashSet<Employee> getEmployees() {
        return employees;
    }

    public void addEmployee(Employee emp) throws DeptNotContainEmpException {
        employees.add(emp);
        emp.setDepartment(this);
    }

    public void removeEmployee(Employee emp) throws DeptNotContainEmpException {
        employees.remove(emp);
        emp.setDepartment(null);
    }

    public void clearEmployee(){
        this.employees = new HashSet<>();
    }

    public int getSize(){
        return this.employees.size();
    }

    public void employeeMove(Employee emp, Department fromDept, Department destDept) throws DeptNotContainEmpException {
        fromDept.removeEmployee(emp);
        destDept.addEmployee(emp);
        fromDept.removeEmployee(emp);
        destDept.addEmployee(emp);

    }

    @Override
    public int compareTo(Department o) {
        return (this.id.compareTo(o.id));
    }


    @Override
    public String toString(){
        StringBuilder str = new StringBuilder();
        str.append(" department id = ");
        str.append(this.id);
        str.append(" department name = ");
        str.append(this.name);
        return str.toString();
    }
}
