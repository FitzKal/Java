import Exceptions.*;
import Model.*;

import java.time.LocalDate;
import java.util.HashSet;

public class Main {
    public static void main(String[] args) throws WrongBirthDateException, DeptNotContainEmpException, SizeException {
            try{
                Person p1 = new Person("Fitz", LocalDate.of(2004, 5,9));
                p1.setNickName("Fitzy");
                //System.out.println(p1);
                Department dep1 = new Department("IK","NP");
                Department dep2 = new Department("br","Cottonfield");
                Department dep3 = new Department("kys","Kurva anyad");
                Employee emp1 = new Employee("Fool", LocalDate.of(2005,5,6), 12,dep1);
                Employee emp2 = new Employee("Kett", LocalDate.of(2005,5,6), 13,dep1);
                Employee emp3 = new Employee("Nigger", LocalDate.of(2005,5,6), 14,dep2);
                Employee emp4 = new Employee("Gipsz Jakab", LocalDate.of(2005,5,6), 15,dep2);
                emp1.setNickName("xd");
                dep1.addEmployee(emp1);
                dep2.addEmployee(emp3);
                dep1.addEmployee(emp4);
                dep1.addEmployee(emp2);
                //dep1.removeEmployee(emp2);
                EmployeeWithSizes es1 = new EmployeeWithSizes("Dj Ferencz", LocalDate.of(2004,5,8), 16,dep2,150,36 );



                /*for (Employee emp : dep1.getEmployees()){
                    System.out.println(emp);
                }*/
                System.out.println(dep1.getSize());
                dep1.employeeMove(emp4,dep1,dep2);
                System.out.println(dep1.getSize());
                for (Employee emp : dep1.getEmployees()){
                    System.out.println(emp);
                }
                for (Employee emp : dep2.getEmployees()){
                    System.out.println(emp);
                }
                System.out.println(dep2.getSize());


                /*System.out.println(emp2);
                System.out.println(emp1.compareTo(emp4));
                System.out.println(emp1.equals(emp4));
                System.out.println(dep1.compareTo(dep2));*/
                Company c1 = new Company("Igen","Verity");
                c1.addDepartment(dep1);
                c1.addDepartment(dep2);
                c1.addDepartment(dep3);
                /*for (Department d : c1.getDepartments()){
                    System.out.println(d);
                }*/


            }catch (WrongBirthDateException e){
                System.out.println(e.getMessage());
            }catch (DeptNotContainEmpException e2){
                System.out.println(e2.getMessage());
            }catch (HeightException he){
                System.out.println(he.getMessage());
            }catch (ShoeSizeException se){
                System.out.println(se.getMessage());
            }


        }
    }
