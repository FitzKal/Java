package Exceptions;

public class HeightException extends SizeException{
    public HeightException(String message) {
        super(message);
    }
}
