package Exceptions;

public class WrongBirthDateException extends CompanyException {
    public WrongBirthDateException(String message) {
        super(message);
    }
}
