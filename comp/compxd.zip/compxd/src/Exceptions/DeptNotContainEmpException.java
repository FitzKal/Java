package Exceptions;

public class DeptNotContainEmpException extends CompanyException{
    public DeptNotContainEmpException(String message) {
        super(message);
    }
}
