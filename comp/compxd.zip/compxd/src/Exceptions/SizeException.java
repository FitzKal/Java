package Exceptions;

public class SizeException extends CompanyException{
    public SizeException(String message) {
        super(message);
    }
}
