package brickset;

public record Dimensions(Double depth, Double height, Double width, Double weight) {
}
