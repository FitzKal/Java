package BoardGame.model;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import org.tinylog.Logger;


public class BoardGameController {
    @FXML
    private GridPane board;

    @FXML
    private TextField numberOfCoinsField;

    private BoardGameModel model = new BoardGameModel();

    @FXML
    private void initialize(){
        for (int i = 0; i < BoardGameModel.BOARDSIZE; i++){
            for (int j = 0; j < BoardGameModel.BOARDSIZE; j++){
                var square = createSquare(i,j);
                board.add(square, j, i);
            }
        }

    }

    private StackPane createSquare(int i, int j) {
        var square = new StackPane();
        var coin = new Circle(50);
        square.getChildren().add(coin);
        coin.setFill(getColor(model.getSquare(i,j)));
        square.setOnMouseClicked(this::handleMouseClick);
        return square;
    }

    private void handleMouseClick(MouseEvent mouseEvent) {
        var square =(StackPane) mouseEvent.getSource();
        var i = GridPane.getRowIndex(square);
        var j = GridPane.getColumnIndex(square);
        Logger.debug("click on ({},{})",i,j);
        model.MakeMove(i,j);
        updateUI(square,getColor(model.getSquare(i,j)));
    }

    private void updateUI(StackPane square, Color color){
        var coin = (Circle)square.getChildren().getFirst();
        coin.setFill(color);
    }

    private void updateNumberOfCoin(){

    }

    private Color getColor(Square square){
        return switch (square){
            case NONE -> Color.TRANSPARENT;
            case HEAD -> Color.RED;
            case TAIL -> Color.BLUE;
        };
    }

}
