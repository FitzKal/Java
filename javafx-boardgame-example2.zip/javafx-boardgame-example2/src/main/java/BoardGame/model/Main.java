package BoardGame.model;

import javafx.application.Application;

import java.awt.event.ActionEvent;

public class Main {
    public static void main(String[] args) {
        Application.launch(BoardGameApplication.class,args);
    }
}
