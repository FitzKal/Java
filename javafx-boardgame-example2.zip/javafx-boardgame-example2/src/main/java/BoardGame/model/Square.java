package BoardGame.model;

public enum Square {
    NONE,
    HEAD,
    TAIL
}
