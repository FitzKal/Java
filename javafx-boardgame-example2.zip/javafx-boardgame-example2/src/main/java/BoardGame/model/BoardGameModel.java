package BoardGame.model;

public class BoardGameModel {
    public static final int BOARDSIZE = 5;

    private Square[][] board;

    private int numberOfCoins;

    public BoardGameModel(){
        board = new Square[BOARDSIZE][BOARDSIZE];
        for (int i = 0; i < BOARDSIZE; i++){
            for (int j = 0; j < BOARDSIZE; j++){
                board[i][j] = Square.NONE;
            }
        }
        numberOfCoins = 0;
    }
    public Square getSquare(int i, int j){
        return board[i][j];
    }

    public int getNumberOfCoins() {
        return numberOfCoins;
    }

    public boolean isLegalMove(int i, int j){
        return 0 <= i && j < BOARDSIZE && 0 <= i && j< BOARDSIZE;
    }

    public void MakeMove(int i, int j){
        board[i][j] = switch (board[i][j]){
            case NONE ->{
                numberOfCoins ++;
                yield  Square.HEAD;
            }
            case HEAD -> Square.TAIL;
            case TAIL ->{
                numberOfCoins --;
                yield  Square.NONE;
            }

        };
    }

    @Override
    public String toString(){
        var sb = new StringBuilder();
        for (int i = 0; i < BOARDSIZE; i++){
            for (int j = 0; j < BOARDSIZE; j++){
                sb.append(board[i][j].ordinal()).append(' ');
            }
            sb.append("\n");
        }
        return sb.toString();
    }
}
